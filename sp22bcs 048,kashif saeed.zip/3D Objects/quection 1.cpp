#include<iostream>
int main()
{
	char* str="Hellow word";
	int*p=reinterpret_cast<int*>(str);
	std::cout<<*p<<std::endl;
	return 0;
}
