#include <iostream>
int main()
{
	int x=10;
	int*p1;
	int*p2;
	p1=&x;
	p2=p1;
	std::cout<<*p1<<std::endl;
	std::cout<<*p2<<std::endl;
	return 0;
}
