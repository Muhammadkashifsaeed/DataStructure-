#include<iostream>
int main()
{
	int*arr;
	arr=(int*)(sizeof(int)*10);
	for(int i=0;i<10;i++){
		arr[i]=i;
	}
	for(int i=0;i<10;i++){
		std::cout<<arr[i]<<std::endl;
	}
	(arr);
	return 0;
}
