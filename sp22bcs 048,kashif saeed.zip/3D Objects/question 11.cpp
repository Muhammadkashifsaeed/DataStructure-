#include<iostream>
int main()
{
	int*p;
	p=reinterpret_cast<char*>("Hellow world");
	std::cout<<*p<<std::endl;
	return 0;
}
