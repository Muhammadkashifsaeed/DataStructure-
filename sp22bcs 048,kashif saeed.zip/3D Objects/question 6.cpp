#include<iostream>
int main()
{
	int*p;
	p=(sizeof(int*));
	*p=10;
	std::cout<<*p<<std::endl;
	(p);
	return 0;
}
