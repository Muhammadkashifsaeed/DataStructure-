#include<iostream>
int main()
{
	int x=10;
	int*p;
	 int y;
	p=&x;
	y=*p;
	std::cout<<y<<std::endl;
	return 0;
}
