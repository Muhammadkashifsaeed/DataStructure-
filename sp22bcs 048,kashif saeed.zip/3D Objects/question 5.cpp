#include<iostream>
int main()
{
	int x=10;
	int*p1;
	int*p2;
	p1=&x;
	p2=&x;
	if(p1==p2){
		std::cout<<"The pointer p1 and p2 point to the same location."<<std::endl;
	}
	else{
		std::cout<<"The pointer p1 and p2 do not point same location."<<std::endl;
	}
return 0;
}
