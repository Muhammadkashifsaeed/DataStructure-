#include<iostream>
int main()
{
	int*arr;
	arr=(int*)(sizeof(int)*10);
	for(int*i=arr;i<arr+10;i++)
	{
		*i=0;
	}
	for(int i=0;i<10;i++){
		std::cout<<arr[i]<<std::endl;
	}
	(arr);
	return 0;
}
